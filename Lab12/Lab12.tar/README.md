CS 332 Systems Programming Lab 12

Run the "make" utility after cloning the repository.

Run the command as "./Lab12 <# of elements> <# of threads>"