CS 332 Systems Programming Lab 13

Run the "make" utility after cloning the repository.

Run the command as "./Lab13 <# of elements> <# of threads>"