#ifndef _PARSELINE_H_  
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
/*
Name: Samuel Casey
BlazerId: scasey18
Project #: 2
*/
void detectInput(char** args, int count);
void parseLine(char* line);
#endif 