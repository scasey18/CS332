#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "createProcess.h"
#include "commands.h"
/*
Name: Samuel Casey
BlazerId: scasey18
Project #: 2
*/

void printArray(char** args, int count){
	int i;
	for (i = 0; i < count; i++){
		printf("[%d] %s\n",i, args[i]);
	}
}
void freeArray(char** args, int count){
	int i;
	for (i = 0; i < count; i++){
		free(args[i]);
	}
	free(args);
}
/**
**  Determine commands built for the shell and those in path or source location
**/
void detectInput(char** args, int count){
	if (!strcmp("list", args[0])){
		createProcess(args, count, list);
	}
	else if (!strcmp("quit",args[0]) && count == 1){
		exit(0);
	}
	else if (!strcmp("cd", args[0])){
		//createProcess(args, count, cd);
		//can not change parent process enviornment from a child process
		//so this is the only function that cannot take place in the child process
		cd(args,count);
	}
	else if (!strcmp("help", args[0])){
		createProcess(args, count, help);
	}
	else if (!strcmp("history", args[0])){
		createProcess(args, count, history);
	}
	else {
		//if the rest of the processes fail then assume it is for another exec
		createProcess(args, count, otherFuncs);
	}
}
/**
** Parses the line taken in from the shell to determine the args
**/
void parseLine(char* line){
	char** args = malloc(1048 * sizeof(char *)); 
	int count = 0;
	char* temp = strtok(line, " ");
	while (temp != NULL){
		args[count] = malloc(strlen(temp)+1 * sizeof(char));
		strcpy(args[count],temp);
		count++;
		temp = strtok(NULL, " ");
	}
	//printArray(args, count);
	detectInput(args, count);
	freeArray(args, count);
}