# Lab4HW

CS332 Lab 4 HW Project
#Input
NameList.csv: This is the example given in the assignment page

#Code
Test.c  : The main file for the assignment
extra.c : Contains all the methods used by the Test.c file
Makefile: use the make utility to generate the HW executable file