Run the make utility after cloning this repository.

Then run "./Lab10 <commands>" in the terminal.

commands should be a line by line file with commands to be run.