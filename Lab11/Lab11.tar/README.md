Run the make utility after cloning this repository.

Then run "./Lab11" in the terminal.

Then with each command input the terminal will execute the command using popen.